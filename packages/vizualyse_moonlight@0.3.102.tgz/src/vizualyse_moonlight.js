// SPDX-License-Identifier: GPL-3.0-or-later
// Copyright (C) 2026 Yousaf Khan
/**
 * vizualyse_moonlight - the iDrive page of the vizualyse-moonlight tool,
 * which streams games from a PC running Sunshine to this screen. Pairing,
 * the host and the game are picked on the phone page the tool serves.
 *
 * The touch screen first: entered, the app opens its empty screen state and
 * the tool's touch screen goes over it (the QR code, the stream and its
 * buttons, Picture on, on / off: the same as the list); its List corner,
 * BACK bring this page back (platform app/touch_mode); parked or driving
 * (a stream stops when the car moves, the touch screen stays). A
 * stream on the centre console covers the touch screen while it plays (the
 * tool hides it and shows it again after).
 *
 * One LT_State_Wide page: the status; Touch screen (the touch screen
 * again); the phone page's link as a QR code
 * (LT_Label_1Graphic_Scalable, a PNG in /dev/shm the HMI can read) and as
 * text; Moonlight on or off; where the picture goes (a drop-down: centre
 * console, cluster, HUD; a stream moves there); Stop (the game keeps running
 * on the PC); Quit game (closes it on the PC); Resume last (the last host
 * and game again); and an info line (host, game, fps, controllers).
 *
 * Only while parked: the app reads the car's speed once a second
 * (vehicle_speed.js) and hands it to the tool, which stops a stream above
 * 3 km/h and starts none. So the app holds the tool's control socket while
 * it runs (moonlight_control.js), not only while its page shows: a stream
 * covers the page. The tool keeps running without it. The structure follows
 * vizualyse_cast.
 */
'use strict';
const { translate } = require('./i18n.js');

const fs = require('fs');
const path = require('path');
const OnlineApp = require('oap-sdk/src/core/OnlineApp.js');
const logging = require('oap-sdk/src/logging/logging');
const { MoonlightControl } = require('./moonlight_control.js');
const { watchSpeed } = require('./vehicle_speed.js');
const { qrPng } = require('./qr_png.js');
const { TouchMode } = require('./touch_mode.js');

const logger = logging.getSDKLogger();

const STATE_NAME = 'ST_OnlineApps_VizualyseMoonlight';
const SCREEN_NAME = 'ST_OnlineApps_VizualyseMoonlightScreen';
const N = {
    status: 'moonlightStatus', touch: 'moonlightTouch', qr: 'moonlightQr', link: 'moonlightLink', hint: 'moonlightHint', info: 'moonlightInfo',
    enable: 'moonlightEnable', stop: 'moonlightStop', quit: 'moonlightQuit', resume: 'moonlightResume', output: 'moonlightOutput',
};
/* the drop-down's rows (tools/make_page.js), as the tool names them */
const OUTPUTS = ['console', 'map', 'hud'];
const PRESS_DEDUPE_MS = 400;
const ROW_CHARS = 90;
const QR_PX = 360;
const QR_PREFIX = 'qr_';

/* The QR folder: world-readable, so the HMI (another uid) can load the PNG. */
function qrDir() {
    if (process.env.MOONLIGHT_QR_DIR) return process.env.MOONLIGHT_QR_DIR;
    const uid = process.getuid ? process.getuid() : 0;
    return '/dev/shm/vizualyse_moonlight_qr_' + uid;
}

/* one row of plain ASCII (the tool's texts carry names from the PC) */
function oneRow(line) {
    const flat = String(line || '').replace(/\s+/g, ' ').replace(/[·–—]/g, '-').replace(/[‘’]/g, "'")
        .replace(/…/g, '...').replace(/[^\x20-\x7e]/g, '?');
    return flat.length > ROW_CHARS ? flat.slice(0, ROW_CHARS - 3) + '...' : flat;
}

/* RHMI event values arrive as booleans, or as 1/0 on some HMIs. */
function isTrue(raw) {
    return raw === true || raw === 'true' || raw === 1 || raw === '1';
}

class MoonlightApp extends OnlineApp {
    constructor() {
        super();
        this._state = null;
        this._screen = null;
        this._touch = null;
        this._components = {};
        this._actionById = {};
        this._lastPress = {};
        this._written = {};
        this._visible = false;
        this._sawForeground = false;
        this._shutdownPromise = null;
        this._qr = { key: null, file: null, chain: Promise.resolve() };
        this._control = new MoonlightControl({ log: logger });
        this._control.on('change', () => { if (this._touch) this._touch.sync(); this._render(); });
        this._control.on('list', () => { if (this._touch) this._touch.list(); });
        this._stopSpeed = null;

        this.on('initialized', () => {
            this._appInitialized()
                .catch((err) => logger.error('vizualyse_moonlight init failed: ' + (err && err.message)));
        });
        this.on('shutdown', (reason) => this._handleShutdown(reason));
        this.on('error', (err) => logger.warn('OnlineApp error: ' + (err && err.message)));
        this.on('entryPointExecute', (uuid) => this._onEntryPointExecute(uuid));
        this.on('changeVisibility', (data) => {
            if (data && data.visible === false) this._setVisible(false);
        });
    }

    _appInitialized() {
        logger.info('vizualyse_moonlight ' + this.getAppId() + ' v' + this._packageJson.version + ' starting');
        if (!this.rhmiApplication) {
            logger.info('no RhmiApplication for this start reason; initializing without a screen');
            return this.initialized();
        }
        const foregroundStart = this._startedForeground();
        /* the tool hears from the app while it runs: the speed, whatever the page */
        this._control.open();
        this._startSpeed();
        return this._setupRhmi()
            .then(() => this._registerEntryPoints())
            .then(() => {
                if (foregroundStart) this.registerActive();
                return this.initialized();
            })
            .then(() => {
                if (foregroundStart) {
                    this._sawForeground = true;
                    this._setVisible(true);
                    this._touch.entered();
                }
                const lastUuid = this.getLastExecutedEntryPointUuid && this.getLastExecutedEntryPointUuid();
                return lastUuid ? this._onEntryPointExecute(lastUuid) : undefined;
            });
    }

    _startSpeed() {
        let builders = null;
        try { builders = require('oap-sdk/src/someip/someipBuilders'); } catch (err) {
            logger.warn('speed: no SOME/IP in this SDK (' + (err && err.message) + '): the tool cannot tell parked from driving');
            return;
        }
        this._stopSpeed = watchSpeed(builders, logger, (kmh) => this._control.speed(kmh));
    }

    _startedForeground() {
        const FOREGROUND_REASONS = ['ENTRY_POINT', 'LUM', 'BOOKMARK', 'START_WIDGET', 'TRIGGER_HMI', 'SPEECH_COMMAND'];
        const data = this.getVisibilityData && this.getVisibilityData();
        const reason = (data && data.reason) || this.startReason;
        return FOREGROUND_REASONS.indexOf(reason) >= 0;
    }

    /* ---- RHMI ---- */
    _setupRhmi() {
        const rhmi = this.rhmiApplication;
        this._state = rhmi.getByName(STATE_NAME);
        if (!this._state) return Promise.reject(new Error('uiDescription has no ' + STATE_NAME));
        const names = Object.keys(N).map((k) => N[k]);
        names.forEach((name) => { this._components[name] = rhmi.getByName(name); });
        const missing = names.filter((name) => !this._components[name]);
        if (missing.length) return Promise.reject(new Error('uiDescription lacks ' + missing.join(', ')));

        this._screen = rhmi.getByName(SCREEN_NAME);
        if (!this._screen) logger.warn('uiDescription has no ' + SCREEN_NAME + ': the touch screen goes over the page');
        const c = this._control;
        this._touch = new TouchMode({ rhmi: rhmi, page: this._state, screen: this._screen, log: logger,
            tool: { connected: () => c.connected(), moving: () => c.moving(), shown: () => c.shown(), show: () => c.showTouch(), hide: () => c.hide() },
            visible: (v) => this._setVisible(v) });
        this._bind(N.touch, () => this._touch.open());
        this._bind(N.enable, () => (this._control.enabled() ? this._control.disable() : this._control.enable()));
        this._bind(N.stop, () => this._control.stop());
        this._bind(N.quit, () => this._control.quit());
        this._bind(N.resume, () => this._control.resume());
        /* the drop-down: the HMI moves its choice itself; the tool's answer decides what it shows */
        this._components[N.output].on('action', (ev) => this._press(N.output, () => {
            const id = OUTPUTS[ev && ev.row];
            delete this._written['selected:' + N.output];
            const r = id ? this._control.output(id) : false;
            this._render();
            return r;
        }));
        rhmi.on('userEvent', (ev) => {
            const entry = ev && ev.eventType === 'ACTION' && this._actionById[Number(ev.sourceId)];
            if (entry) this._press(entry.name, entry.handler);
        });
        rhmi.on('applicationStackChanged', (stack) => {
            const keys = stack && typeof stack === 'object' ? Object.keys(stack) : [];
            if (!keys.length) return;
            if (Object.prototype.hasOwnProperty.call(stack, 'ROOT_APP')) {
                this._sawForeground = true;
                this._setVisible(true);
            } else if (this._sawForeground) {
                this._setVisible(false);
            }
        });
        rhmi.on('restoreHmi', () => {
            logger.info('RESTORE_HMI: re-pushing page content');
            this._written = {};
            this._qr.key = null;
            this._render();
        });
        /* the app's visibility: either state's (TouchMode's visible()) */
        this._state.on('visible', (event) => { if (isTrue(event && event.visible)) this._sawForeground = true; });
        return Promise.resolve(this._state.updateResources()).then(() => {
            logger.info('page ready: ' + names.length + ' components found');
            this._render();
        });
    }

    _bind(name, handler) {
        const comp = this._components[name];
        let id = null;
        try { id = comp.getId(); } catch (e) { id = null; }
        if (id !== null) this._actionById[Number(id)] = { name: name, handler: handler };
        comp.on('action', () => this._press(name, handler));
    }

    _press(name, handler) {
        const now = Date.now();
        if (now - (this._lastPress[name] || 0) < PRESS_DEDUPE_MS) return;
        this._lastPress[name] = now;
        logger.info('BUTTON ACTION ' + name);
        try {
            if (handler() === false) logger.warn(name + ': the Moonlight service is not connected');
        } catch (err) {
            logger.warn(name + ' failed: ' + (err && err.message));
        }
    }

    /* The app manager inserts the tile from application.json and hands it to
     * the app at start; the SDK emits 'entryPointExecute' on a tap. */
    _registerEntryPoints() {
        const descriptions = (this.appDescription && this.appDescription.application.entryPoints) || [];
        const ours = this.getEntryPoints().find((ep) => descriptions.some((d) => d.uuid === ep.getDescription().uuid));
        if (!ours) return Promise.reject(new Error('no entry point handed over by the manager'));
        const description = ours.getDescription();
        return ours.init()
            .then(() => this.rhmiApplication.mapEntryState(description.uuid, this._state))
            .then(() => Promise.resolve()
                .then(() => ours.entryPoint.setText(description.textId))
                .then(() => (description.icon ? ours.entryPoint.setIcon(description.icon) : undefined))
                .catch((err) => logger.warn('entry point text/icon: ' + (err && err.message))))
            .then(() => ours.setAvailability('ENABLED'))
            .then(() => logger.info('entry point ' + description.name + ' ENABLED'));
    }

    _onEntryPointExecute(uuid) {
        if (this._shutdownPromise || !this.rhmiApplication || !uuid) return Promise.resolve();
        this._sawForeground = true;
        this._setVisible(true);
        if (this._touch) this._touch.entered();
        return Promise.resolve(this.rhmiApplication.openEntryState(uuid))
            .catch((err) => logger.warn('openEntryState failed: ' + (err && err.message)));
    }

    /* ---- visibility ---- */
    _setVisible(visible) {
        if (this._shutdownPromise || this._visible === visible) return;
        this._visible = visible;
        logger.info('page ' + (visible ? 'visible' : 'hidden'));
        this._reportVisibilityStatus(visible);
    }

    _reportVisibilityStatus(visible) {
        if (!this._initialized || !this._appStatusService) return;
        const reports = visible ? [this.registerActive(), this.registerHmiVisible()]
            : [this.unregisterHmiVisible(), this.registerInactive()];
        reports.forEach((report) => Promise.resolve(report).catch((err) =>
            logger.warn('app status report failed: ' + (err && err.message))));
    }

    /* ---- rendering ---- */
    _write(name, text) {
        const t = oneRow(translate(text));
        if (this._written[name] !== t) {
            this._written[name] = t;
            Promise.resolve(this._components[name].setValue(0, 'Text', t, 'Text'))
                .catch((err) => logger.warn(name + ' render failed: ' + (err && err.message)));
        }
    }

    _setEnabled(name, enabled) {
        const key = 'enabled:' + name;
        if (this._written[key] !== enabled) {
            this._written[key] = enabled;
            /* a drop-down has no setEnabled, only the property (upstream's Waze) */
            const comp = this._components[name];
            Promise.resolve(comp.setEnabled ? comp.setEnabled(enabled) : comp.setProperty('Enabled', enabled ? 1 : 0, 'UInt'))
                .catch((err) => logger.warn(name + ' enable failed: ' + (err && err.message)));
        }
    }

    /* A drop-down's choice (three arguments: no row) */
    _select(name, index) {
        const key = 'selected:' + name;
        if (this._written[key] !== index) {
            this._written[key] = index;
            Promise.resolve(this._components[name].setValue('SelectedItem', index, 'UInt'))
                .catch((err) => logger.warn(name + ' selection failed: ' + (err && err.message)));
        }
    }

    _show(name, visible) {
        const key = 'visible:' + name;
        if (this._written[key] !== visible) {
            this._written[key] = visible;
            Promise.resolve(this._components[name].setVisible(visible))
                .catch((err) => logger.warn(name + ' visibility failed: ' + (err && err.message)));
        }
    }

    _render() {
        if (!this._state || this._shutdownPromise) return;
        const c = this._control, up = c.connected(), link = up && c.enabled() ? c.link() : '';
        /* while the touch screen covers the page itself (no screen state), nothing under it can be pressed */
        const covered = this._touch ? this._touch.covered() : false;
        const on = up && c.enabled() && !covered;
        this._write(N.status, c.statusText());
        this._write(N.touch, 'Touch screen');
        this._setEnabled(N.touch, up && !covered);
        this._write(N.link, link ? link : '');
        this._write(N.hint, link ? 'Scan with the phone whose hotspot the car is on to pair and pick the PC and game' : '');
        this._write(N.info, c.infoText());
        this._write(N.enable, 'Moonlight: ' + (up ? (c.enabled() ? 'on' : 'off') : 'not running'));
        this._setEnabled(N.enable, up && !covered);
        this._setEnabled(N.stop, on && c.active());
        this._setEnabled(N.quit, on && c.active());
        this._setEnabled(N.resume, on && !c.active() && c.canResume());
        this._setEnabled(N.output, on);
        this._select(N.output, Math.max(0, OUTPUTS.indexOf(c.currentOutput())));
        this._showQr(link);
    }

    /* The link as a QR code: a new PNG file for each new link (the HMI does
     * not load a path again), the old one released once the new one shows. */
    _showQr(text) {
        const q = this._qr, comp = this._components[N.qr], rhmi = this.rhmiApplication;
        this._show(N.qr, !!text);
        if (q.key === (text || '') || !comp || !rhmi) return;
        q.key = text || '';
        q.chain = q.chain.then(() => {
            const bundle = rhmi.getResourceBundle();
            const old = q.file;
            if (!text) {
                q.file = null;
                return old ? this._retireQr(bundle, old) : undefined;
            }
            const dir = qrDir();
            if (!fs.existsSync(dir)) fs.mkdirSync(dir);
            fs.chmodSync(dir, 0o755);
            const r = qrPng(text, QR_PX);
            const file = path.join(dir, QR_PREFIX + Date.now() + '.png');
            fs.writeFileSync(file, r.png);
            fs.chmodSync(file, 0o644);
            return Promise.resolve(bundle.createResourceHandles([file]))
                .then(() => comp.setValue(0, 'Graphic', file, 'ResourceId'))
                .then(() => rhmi.flush())
                .then(() => {
                    q.file = file;
                    logger.info('QR code ' + r.width + 'x' + r.width + ' px (' + r.modules + ' modules)');
                    return old ? this._retireQr(bundle, old) : undefined;
                }, (err) => this._retireQr(bundle, file).then(() => { throw err; }));
        }).catch((err) => {
            q.key = null;
            logger.warn('QR code failed: ' + (err && err.message));
        });
    }

    _retireQr(bundle, file) {
        return Promise.resolve()
            .then(() => bundle.destroyResourceHandles([file]))
            .catch((err) => logger.warn('QR handle ' + path.basename(file) + ': ' + (err && err.message)))
            .then(() => { try { fs.unlinkSync(file); } catch (e) { /* gone already */ } });
    }

    /* ---- shutdown ---- */
    _handleShutdown(reason) {
        if (this._shutdownPromise) return this._shutdownPromise;
        logger.info('vizualyse_moonlight shutdown: ' + JSON.stringify(reason));
        if (this._stopSpeed) this._stopSpeed();
        if (this._touch) this._touch.stop(); else this._control.hide();
        this._control.close();
        const bundle = this.rhmiApplication && this.rhmiApplication.getResourceBundle();
        this._shutdownPromise = Promise.resolve()
            .then(() => (this._qr.file && bundle ? this._retireQr(bundle, this._qr.file) : undefined))
            .then(() => this.destroyBundles().catch((err) => logger.info('destroyBundles: ' + (err && err.message))))
            .then(() => process.exit(0));
        return this._shutdownPromise;
    }
}

const app = new MoonlightApp();
app.start().catch((err) => {
    /* Stays resident so the manager can stop or restart it. */
    logger.error('vizualyse_moonlight failed to start: ' + (err && err.message));
});
