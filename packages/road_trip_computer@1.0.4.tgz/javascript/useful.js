'use strict';
/**
 * useful.js - the values worth a look, per control unit address, in groups (Show = Useful).
 *
 * Each value lists candidates, best first: a catalog identifier ('4402', or '4163/1' for the
 * second value of 4163) or a standard one from std.js ('OBD 05', 'F190'). The first candidate the
 * car answers is shown; units that differ are converted (hPa / kPa / MPa -> bar, ml/s -> l/h ...).
 *   { name, c: [candidates], u: unit to show, d: decimals }
 *   { name, minus: [a, b], u, d }  a - b (each converted to u), e.g. boost = charge pressure - ambient
 * optional: bad: [raw values that mean "no data"] (a candidate with one is skipped, e.g. FFFF while
 * the engine is off), map: { raw: text }, lin: [a, b] (shown as a + b * value). Temperatures below
 * -45 °C count as no data (an unset sensor reads -48 or -273).
 * Engine unit identifiers: DME8FF_R (B58 / B48 / B38, G series); one that isn't there is skipped.
 */
const cyl = (name, dids, extra) => dids.map((did, i) => Object.assign({ name: name + ', cylinder ' + (i + 1), c: [did] }, extra));

const DME = [
    { group: 'Engine', items: [
        { name: 'Engine speed', c: ['4807', 'OBD 0C'], u: 'rpm', d: 0 },      // the engine unit's own: shares a request
        { name: 'Engine load', c: ['OBD 04'], u: '%', d: 0 },
        { name: 'Accelerator pedal', c: ['5814', '480B', 'OBD 49'], u: '%', d: 0 },
        { name: 'Throttle', c: ['4600', '5858', 'OBD 11'], u: '%', d: 0 },
        { name: 'Engine torque', c: ['5891', '5717'], u: 'Nm', d: 0 },
        { name: 'Engine power (engine unit)', c: ['4520'], d: 0 },
        { name: 'Vehicle speed', c: ['4AB1', 'OBD 0D'], u: 'km/h', d: 0 },
        { name: 'Gear', c: ['5881', '564F'], d: 0 },
        { name: 'Time since engine start', c: ['OBD 1F'], u: 's', d: 0 },
    ] },
    { group: 'Temperatures', items: [
        { name: 'Coolant', c: ['4300', '5805', 'OBD 05'], u: '°C', d: 0 },
        { name: 'Coolant, radiator outlet', c: ['5890'], u: '°C', d: 0 },
        { name: 'Engine oil (after filter)', c: ['4402', '5822', 'OBD 5C'], u: '°C', d: 0 },
        { name: 'Engine oil in the sump', c: ['4425', '4408'], u: '°C', d: 0 },
        { name: 'Intake air', c: ['580F', 'OBD 0F'], u: '°C', d: 0 },
        { name: 'Charge air before throttle', c: ['59D4'], u: '°C', d: 0 },
        { name: 'Outside', c: ['5817', '5512', 'OBD 46'], u: '°C', d: 1 },
        { name: 'Gearbox', c: ['4650'], u: '°C', d: 0 },
        { name: 'Fuel', c: ['4AD5'], u: '°C', d: 0 },
        { name: 'Engine unit', c: ['5821'], u: '°C', d: 0 },
        { name: 'Exhaust after catalyst (model)', c: ['5896', '582F'], u: '°C', d: 0 },
        { name: 'Particulate filter', c: ['579B'], u: '°C', d: 0 },
        { name: 'Catalyst, bank 1 sensor 1', c: ['OBD 3C'], u: '°C', d: 0 },
    ] },
    { group: 'Oil', items: [
        // both oil pressure identifiers read absolute (1.02 bar with the engine off): above ambient = what the pump makes
        { name: 'Oil pressure', minus: ['4436', '4201'], u: 'bar', d: 2 },
        { name: 'Oil pressure (absolute)', c: ['586F', '4436'], u: 'bar', d: 2 },
        { name: 'Oil level above minimum', c: ['5811', '442F'], u: 'l', d: 2, bad: [255] },
        { name: 'Oil level', c: ['4409'], u: 'mm', d: 1 },
        { name: 'Oil life left (by engine hours)', c: ['411A/0'], u: '%', d: 0 },
        { name: 'Oil life left (by fuel used)', c: ['411A/1'], u: '%', d: 0 },
        { name: 'Engine hours on this oil', c: ['411A/2'], u: 'h', d: 0 },
        { name: 'Distance on this oil', c: ['4404'], u: 'km', d: 0 },
        { name: 'Fuel in the oil', c: ['593A'], u: 'g', d: 0 },
        { name: 'Oil pump duty cycle', c: ['4AAA'], u: '%', d: 0 },
    ] },
    { group: 'Fuel', items: [
        { name: 'Fuel in the tank', c: ['583B'], u: 'l', d: 0 },
        { name: 'Fuel tank, left half', c: ['5949'], u: 'l', d: 1 },
        { name: 'Fuel tank, right half', c: ['594A'], u: 'l', d: 1 },
        { name: 'Fuel tank level', c: ['OBD 2F'], u: '%', d: 0 },
        { name: 'Time since refuelling', c: ['57E3'], u: 'h', d: 1 },
        { name: 'High pressure fuel (rail)', c: ['58EF', '5658', 'OBD 23'], u: 'bar', d: 0 },
        { name: 'High pressure fuel target', c: ['5837', '56C1'], u: 'bar', d: 0 },
        { name: 'Low pressure fuel', c: ['58F3', '5463'], u: 'bar', d: 2 },
        { name: 'Fuel consumption', c: ['5656', 'OBD 5E'], u: 'l/h', d: 1 },
        { name: 'Fuel mass flow', c: ['4521'], u: 'kg/h', d: 1 },
        { name: 'Ethanol in the fuel', c: ['550D', 'OBD 52'], u: '%', d: 0 },
        { name: 'Fuel quality (adapted)', c: ['5776'], u: 'RON', lin: [98, -7], d: 1 },
    ] },
    { group: 'Boost and air', items: [
        { name: 'Boost', minus: ['4205', '4201'], u: 'bar', d: 2 },
        { name: 'Charge pressure (absolute)', c: ['4205', '57C1'], u: 'bar', d: 2 },
        { name: 'Boost target (absolute)', c: ['4AB0'], u: 'bar', d: 2 },
        { name: 'Boost control deviation', c: ['4536'], u: 'hPa', d: 0 },
        { name: 'Intake manifold pressure', c: ['4A2D', 'OBD 0B'], u: 'bar', d: 2 },
        { name: 'Ambient pressure', c: ['4201', 'OBD 33'], u: 'hPa', d: 0 },
        // no air mass meter on this engine (coding: HFM 0, its identifiers read 0): the engine unit's own figure
        { name: 'Air mass flow', c: ['5511', '4ABC', '56BA', '4206', '5812', 'OBD 10'], u: 'kg/h', d: 0, bad: [0] },
        { name: 'Air charge (relative)', c: ['5813', 'OBD 43'], u: '%', d: 0 },
        { name: 'Wastegate position (0 = closed)', c: ['5927'], u: '%', d: 0 },
        { name: 'Wastegate actuator duty cycle', c: ['4AAB'], u: '%', d: 0 },
    ] },
    { group: 'Ignition and knock', items: [
        { name: 'Ignition angle', c: ['59FA', 'OBD 0E'], u: '°', d: 1 },
    ].concat(cyl('Ignition angle', ['4A49', '4A4A', '4A4C', '4A4D', '4A4E', '4A4F'], { u: '°', d: 1 }), [
        { name: 'Knock detected', c: ['4A36'], map: { 0: 'no', 1: 'YES' } },
        { name: 'Knock control retard (mean)', c: ['554C'], u: '°', d: 1 },
        { name: 'Knock control adaptation', c: ['554A'], u: '°', d: 1 },
    ], cyl('Misfires', ['4B23', '4B24', '4B25', '4B30', '4B31', '4B32'], { d: 0 }),
    cyl('Rough running', ['4A30', '4A31', '4A32', '4A33', '4A34', '4A35'], { d: 1 })) },
    { group: 'VANOS and Valvetronic', items: [
        { name: 'Intake camshaft (VANOS)', c: ['452E'], u: '°', d: 1 },
        { name: 'Intake camshaft target', c: ['452B'], u: '°', d: 1 },
        { name: 'Exhaust camshaft (VANOS)', c: ['452C'], u: '°', d: 1 },
        { name: 'Exhaust camshaft target', c: ['452A'], u: '°', d: 1 },
        { name: 'Intake valve lift (Valvetronic)', c: ['4602'], u: 'mm', d: 2 },
        { name: 'Intake valve lift target', c: ['4603'], u: 'mm', d: 2 },
    ] },
    { group: 'Mixture and injectors', items: [
        { name: 'Lambda', c: ['5889', '5640', 'OBD 34'], d: 3, bad: [65535] },
        { name: 'Lambda target', c: ['5816', 'OBD 44'], d: 3, bad: [65535] },
        { name: 'Short term fuel trim', c: ['OBD 06'], u: '%', d: 1 },
        { name: 'Long term fuel trim', c: ['OBD 07'], u: '%', d: 1 },
        { name: 'Mixture adaptation (factor)', c: ['4A9D'], d: 3 },
        { name: 'Injector flow adaptation (mean)', c: ['546E'], d: 3 },
    ].concat(cyl('Injector correction', ['55B4', '55B5', '55B6', '55B7', '55B8', '55B9'], { d: 3 })) },
    { group: 'Battery and charging', items: [
        { name: 'Battery voltage', c: ['5853', 'OBD 42'], u: 'V', d: 2 },
        { name: 'Battery current', c: ['5852'], u: 'A', d: 1 },
        { name: 'Battery temperature', c: ['5854'], u: '°C', d: 0 },
        { name: 'Battery charge', c: ['56F0'], u: '%', d: 0, bad: [0] },
        { name: 'Battery health', c: ['59AA'], u: '%', d: 0 },
        { name: 'Alternator current', c: ['4604'], u: 'A', d: 0 },
    ] },
    { group: 'Wear and service', items: [
        { name: 'Spark plugs: remaining distance', c: ['4163/1', '5489'], u: 'km', d: 0, bad: [0] },
        { name: 'Spark plugs: distance driven', c: ['4163/2'], u: 'km', d: 0 },
        { name: 'Spark plug wear (normalised)', c: ['4163/0'], d: 3, bad: [0] },
        { name: 'Particulate filter: soot', c: ['5444', '5774'], u: 'g', d: 1 },
        { name: 'Particulate filter: load (adapted)', c: ['558C'], d: 3 },
        { name: 'Particulate filter: ash (adapted)', c: ['558B'], d: 3 },
        { name: 'Catalyst oxygen storage', c: ['5433'], u: 'mg', d: 0, bad: [0] },
        { name: 'Engine operating hours', c: ['583D'], u: 'h', d: 0 },
        { name: 'Check engine lamp (MIL) on', c: ['OBD 01'] },
        { name: 'Stored emission faults', c: ['OBD 01/1'] },
    ] },
];

// unit conversions: from -> to -> factor
const CONVERT = {
    hPa: { bar: 0.001 }, kPa: { bar: 0.01, hPa: 10 }, MPa: { bar: 10 }, 'ml/s': { 'l/h': 3.6 }, 'g/s': { 'kg/h': 3.6 },
    cl: { l: 0.01 }, min: { h: 1 / 60 }, s: { h: 1 / 3600 }, '°CA': { '°': 1 }, '°C': { '°': 1 },
};

module.exports = { 0x12: DME, CONVERT };
