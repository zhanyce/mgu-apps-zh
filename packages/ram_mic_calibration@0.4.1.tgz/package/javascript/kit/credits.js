'use strict';
const CREDIT = '';
const { getLanguage } = require('./i18n');
function drawCredit(canvas, x, baseline) {
    if (getLanguage() !== 'zh-CN') return;
    canvas.text(CREDIT, x, baseline, 12, '#ffffff40', { align: 'right', font: 'label' });
}
module.exports = { CREDIT, drawCredit };
