'use strict';
const G = require('./kit/gauges');

function lines(cv, text, x, y, width, size, color) {
    let line = '', row = 0;
    for (const ch of text) {
        if (line && cv.textWidth(line + ch, size, { literal: true }) > width) {
            cv.text(line, x, y + row * 34, size, color, { literal: true });
            line = ch;
            row++;
        } else line += ch;
    }
    if (line) cv.text(line, x, y + row * 34, size, color, { literal: true });
}

function home(cv, t, ready, status, busy, actions) {
    cv.clear(t.bg);
    G.panel(cv, t, 24, 44, 940, 372, '校准前准备');
    G.panel(cv, t, 986, 44, 590, 372, 'RAM01 状态');
    const conditions = [
        '停车，保持点火接通与供电稳定',
        '移走大件物品，确保扬声器无遮挡',
        '关闭侧窗和天窗',
        '倒计时期间全员下车并关好车门',
    ];
    conditions.forEach((text, i) => cv.text(text, 50, 139 + i * 55, 27, t.text, { literal: true }));
    cv.text('注意：校准会播放很响的测试音', 50, 380, 25, t.warn, { literal: true });
    lines(cv, status, 1010, 143, 540, 25, t.text);
    const color = ready ? t.ok : t.dim;
    cv.strokeRoundRect(1010, 345, 26, 26, 5, 2, color);
    if (ready) {
        cv.line(1015, 358, 1021, 364, 3, color);
        cv.line(1021, 364, 1031, 352, 3, color);
    }
    cv.text('已检查准备条件', 1052, 368, 26, color, { literal: true });
    G.button(cv, t, 24, 435, 230, 58, '读取状态', actions.read, { busy });
    G.button(cv, t, 276, 435, 250, 58, ready ? '重新确认' : '确认准备', actions.toggleReady, { busy });
    G.button(cv, t, 548, 435, 290, 58, '开始倒计时', actions.start, { busy: busy || !ready, primary: true });
    G.frame(cv, t, ['麦克风校准'], 0);
}

function countdown(cv, t, seconds, status, beforeStart, cancel) {
    cv.clear(t.bg);
    G.panel(cv, t, 24, 44, 1552, 372, seconds > 0 ? '下车准备' : '麦克风校准');
    if (seconds > 0) {
        cv.text(String(seconds), 800, 260, 112, t.text, { align: 'center', font: 'num' });
        cv.fillRect(480, 290, 640, 5, t.track);
        cv.fillRect(480, 290, 640 * Math.min(seconds, 30) / 30, 5, t.accent);
    }
    cv.text(status, 800, seconds > 0 ? 365 : 250, 29, t.text, { align: 'center', literal: true });
    if (beforeStart) G.button(cv, t, 665, 435, 270, 58, '取消校准', cancel);
    G.frame(cv, t, ['麦克风校准'], 0);
}

module.exports = { home, countdown };

