'use strict';
/**
 * record.js - the drawing surface apps draw on: same methods as canvas.js, but every call is
 * recorded as a compact command (32-bit words, see kit/renderd/src/proto.h) instead of being
 * rasterised in JavaScript.
 *
 * A recording is then either
 *   - sent to mgu-renderd, which draws it on the GPU straight onto the screen (60 fps), or
 *   - played back into a canvas.js Canvas (play()) and handed to the HMI as a PNG - the
 *     fallback when the renderer is not running, and what the PC preview uses.
 *
 * Recording a whole frame costs well under a millisecond; nothing here touches pixels.
 */
const { Canvas, rgba } = require('./canvas');
const arabic = require('./arabic');
const fonts = require('./fonts');
const { t } = require('./i18n');

const OP = {
    CLEAR: 1, RECT: 2, GRAD: 3, RRECT: 4, RSTROKE: 5, CARD: 6, RAMPRECT: 7, ARC: 8, LINE: 9,
    TRIS: 10, GLYPHS: 11, LAYER: 12, CLIP: 13, NOCLIP: 14, QUAD: 15, ALPHA: 16, XF: 17, IMAGE: 18, VIDEO: 19,
};

/* ---------- colours: 0xRRGGBBAA ---------- */
const packCache = new Map();
function pack(c) {
    if (typeof c === 'number') return c >>> 0;
    if (typeof c === 'string') {
        let v = packCache.get(c);
        if (v === undefined) { const a = rgba(c); v = (((a[0] & 255) << 24) | ((a[1] & 255) << 16) | ((a[2] & 255) << 8) | (a[3] & 255)) >>> 0; packCache.set(c, v); }
        return v;
    }
    const a = rgba(c);
    return ((((Math.round(a[0]) & 255) << 24) | ((Math.round(a[1]) & 255) << 16) | ((Math.round(a[2]) & 255) << 8) | (Math.round(a[3]) & 255)) >>> 0);
}
function unpack(v) { return [v >>> 24, (v >>> 16) & 255, (v >>> 8) & 255, v & 255]; }

/* ---------- registries shared by recorders and the transports ---------- */
// colour ramps: stops array -> id
const rampIds = new Map(), rampList = [];
function rampId(stops) {
    const key = stops.join(',');
    let id = rampIds.get(key);
    if (id === undefined) { id = rampList.length + 1; rampIds.set(key, id); rampList[id] = stops.map((s) => (typeof s === 'string' ? s : rgba(s))); }
    return id;
}
// glyph atlases: font object (family+size) -> id
const atlasIds = new Map(), atlasList = [];
function atlasId(f, family) {
    let id = atlasIds.get(f);
    if (id === undefined) {
        // stable across runs and apps (the daemon shares atlases by id): family + size
        id = 0;
        const k = family + '@' + f.size + (f.cacheKey ? '#' + f.cacheKey : '');
        for (let i = 0; i < k.length; i++) id = (Math.imul(id, 31) + k.charCodeAt(i)) >>> 0;
        id = (id | 1) >>> 0;
        atlasIds.set(f, id); atlasList.push({ id, f });
    }
    return id;
}
function atlasById(id) { const a = atlasList.find((x) => x.id === id); return a ? a.f : null; }
/*
 * Atlases the renderer refused (its one glyph texture, shared by every app, is full: "glyph atlas
 * texture full"; renderd.js finds out which): text that would use one is drawn with another baked
 * size of the same font instead (the nearest, a larger one first), else the kit's label font, so no
 * characters go missing. For the life of the process.
 */
const badAtlas = new Set();
function markBadAtlas(id) { badAtlas.add(id); }
function font(family, size, s) {
    const f = fonts.get(family, size, s);
    if (!f || !badAtlas.size || !badAtlas.has(atlasId(f, f.family || family))) return f;
    const ok = (x) => !badAtlas.has(atlasId(x, x.family || family));
    const alt = (list) => list.filter(ok).sort((a, b) => {
        const da = a.size >= size ? a.size - size : (size - a.size) * 3, db = b.size >= size ? b.size - size : (size - b.size) * 3;
        return da - db;
    })[0];
    const same = alt(fonts.sizes(f.family || family));
    if (same) return fonts.ready(same);
    const lab = alt(fonts.sizes('label'));
    return lab ? fonts.ready(lab) : f;
}

// pixel images (e.g. a game's frame): id -> { w, h, data (RGBA bytes), ver }. setImage() bumps ver;
// a frame records id + ver, so a changed picture is a changed frame, and the transport uploads it
const imageById = new Map();
function setImage(id, w, h, data) {
    const im = imageById.get(id) || { ver: 0 };
    im.w = w | 0; im.h = h | 0; im.data = data; im.ver = (im.ver + 1) >>> 0;
    imageById.set(id, im);
    return im;
}
/** Forget pixel image `id` (its pixels are let go; frames drawing it draw nothing until it is set again). */
function dropImage(id) { imageById.delete(id); }

// cached layers (static parts of widgets): drawn once, used by id
let layerSeq = 0;
const layerById = new Map();

class Recorder {
    /**
     * w, h: logical size. opts.textScale: device pixels per logical pixel (text then uses the
     * glyph size it will really be shown at, so scaled-up text stays sharp).
     */
    constructor(w, h, opts) {
        this.w = w | 0; this.h = h | 0;
        this.textScale = (opts && opts.textScale) || 1;
        this.buf = new ArrayBuffer(65536);
        this.f = new Float32Array(this.buf);
        this.u = new Uint32Array(this.buf);
        this.n = 0;
        this.layersUsed = null;      // Set of layer ids this recording draws
        this.atlases = new Set();    // glyph atlases and colour ramps it uses (uploaded once by the transport)
        this.ramps = new Set();
        this.images = new Set();     // pixel images it draws (setImage)
        this.targets = [];           // what a tap or the controller can press on the page: { x, y, w, h, run, key, r, quiet } (target)
        this.pictures = 'blend';     // how its pixel images (op 18) are shown: Display.canvas() says (see there)
        this._extra = 0;
        this.extraUsed = false;      // the drawing read extra (it reaches below the page: display.js places it so)
        this.recording = true;
        this.bleeds = [];            // the page's background, marked (bgStart / bgEnd): [from, to, edge] word ranges
        this._bgAt = -1; this._bgBad = false;
    }
    /** logical px the screen has below the app's page (display.js), 0 if none */
    get extra() { if (this._extra) this.extraUsed = true; return this._extra; }
    set extra(v) { this._extra = v || 0; }
    reset() { this.n = 0; this.bleeds = []; this._bgAt = -1; this._bgBad = false; this._cnStamped = false; this.targets = []; this.scroll = false; this.extraUsed = false; if (this.layersUsed) this.layersUsed.clear(); this.atlases.clear(); this.ramps.clear(); this.images.clear(); return this; }
    _grow(k) {
        if (this.n + k <= this.u.length) return;
        let len = this.u.length * 2;
        while (len < this.n + k) len *= 2;
        const nb = new ArrayBuffer(len * 4);
        new Uint32Array(nb).set(this.u.subarray(0, this.n));
        this.buf = nb; this.f = new Float32Array(nb); this.u = new Uint32Array(nb);
    }
    /**
     * Mark what follows, up to bgEnd(), as the page's background (sky, bands, waves: no text, no
     * buttons). The full-screen layout draws it again, from screen x 0, under the HMI's back
     * arrow column (display.js _bleed), so the page's art reaches the screen's left edge.
     * edge: 'wrap' (the default: the page's right end continues to its left, as a 1600 px wide
     * scrolling or plain background does), 'repeat' (its own left edge, again) or 'none'. A mark
     * holding a clip, xf, clear, video or append is dropped (it would escape the column).
     */
    bgStart() { this._bgAt = this.n; this._bgBad = false; return this; }
    bgEnd(edge) {
        if (this._bgAt >= 0 && !this._bgBad && this.n > this._bgAt && edge !== 'none') this.bleeds.push([this._bgAt, this.n, edge === 'repeat' ? 'repeat' : 'wrap']);
        this._bgAt = -1; this._bgBad = false;
        return this;
    }
    /**
     * draw(r): what shows left of the page instead (at negative x, in the page's own units), e.g. a
     * picture's edge stretched; kept aside, drawn only under the back arrow column (not on the page).
     */
    bgEdge(draw) {
        const at = this.n;
        this._bgAt = at; this._bgBad = false;
        try { draw(this); } finally {
            if (!this._bgBad && this.n > at) this.bleeds.push([0, 0, 'own', this.u.slice(at, this.n)]);
            this.n = at; this._bgAt = -1; this._bgBad = false;
        }
        return this;
    }
    _bgOff() { if (this._bgAt >= 0) this._bgBad = true; }
    /** the recorded words (a view, valid until the next draw call) */
    words() { return this.u.subarray(0, this.n); }
    /**
     * Something on the page a tap (or the iDrive controller, turned onto it and pressed) runs: run().
     * key names it from frame to frame (the controller stays on it). Drawn by the caller; where the kit
     * runs the screen (display.js) it rings the one the controller is on.
     */
    /**
     * A page target. o.quiet: the kit draws no 35% press flash over it and the controller's ring is a
     * circle around its middle, not the rect's outline (buttons that draw their own soft press state).
     */
    target(x, y, w, h, run, key, r, o) { this.targets.push({ x, y, w, h, run, key: String(key), r, quiet: !!(o && o.quiet) }); return this; }

    /* ---------- canvas.js API ---------- */
    /** Draw pixel image `id` (see setImage) scaled into x, y, w, h (nearest pixel). */
    image(id, x, y, w, h) {
        const im = imageById.get(id);
        if (!im || !(w > 0 && h > 0)) return this;
        this._grow(7); const f = this.f, i = this.n;
        this.u[i] = OP.IMAGE; this.u[i + 1] = id; this.u[i + 2] = im.ver; f[i + 3] = x; f[i + 4] = y; f[i + 5] = w; f[i + 6] = h;
        this.images.add(id);
        this.n += 7; return this;
    }
    /**
     * Draw video `id` (renderd.js RenderClient.video: frames from another writer, mgu-render/1 with caps
     * bit 16 only) fitted into x, y, w, h, aspect kept. Recorded in the renderer's own layout
     * (op 19: x y w h r id); the software path draws nothing for it.
     */
    video(id, x, y, w, h) {
        if (!(w > 0 && h > 0)) return this;
        this._bgOff();
        this._grow(7); const f = this.f, i = this.n;
        this.u[i] = OP.VIDEO; f[i + 1] = x; f[i + 2] = y; f[i + 3] = w; f[i + 4] = h; f[i + 5] = 0; this.u[i + 6] = id >>> 0;
        this.n += 7; return this;
    }
    clear(c) { this._bgOff(); this._grow(2); this.u[this.n++] = OP.CLEAR; this.u[this.n++] = pack(c || [0, 0, 0, 0]); return this; }

    fillRect(x, y, w, h, c) {
        if (!(w > 0 && h > 0)) return this;
        this._grow(6); const f = this.f, i = this.n;
        this.u[i] = OP.RECT; f[i + 1] = x; f[i + 2] = y; f[i + 3] = w; f[i + 4] = h; this.u[i + 5] = pack(c);
        this.n += 6; return this;
    }
    gradientRect(x, y, w, h, stops) { return this._grad(OP.GRAD, x, y, w, h, 0, stops); }
    card(x, y, w, h, r, stops) { return this._grad(OP.CARD, x, y, w, h, r, stops); }
    _grad(op, x, y, w, h, r, stops) {
        const k = stops.length, card = op === OP.CARD;
        this._grow(7 + k * 2); const f = this.f; let i = this.n;
        this.u[i++] = op; f[i++] = x; f[i++] = y; f[i++] = w; f[i++] = h;
        if (card) f[i++] = r;
        this.u[i++] = k;
        for (const s of stops) { f[i++] = s[0]; this.u[i++] = pack(s[1]); }
        this.n = i; return this;
    }
    roundRect(x, y, w, h, r, c) {
        if (!(w > 0 && h > 0)) return this;
        this._grow(7); const f = this.f, i = this.n;
        this.u[i] = OP.RRECT; f[i + 1] = x; f[i + 2] = y; f[i + 3] = w; f[i + 4] = h; f[i + 5] = r; this.u[i + 6] = pack(c);
        this.n += 7; return this;
    }
    strokeRoundRect(x, y, w, h, r, width, c) {
        this._grow(8); const f = this.f, i = this.n;
        this.u[i] = OP.RSTROKE; f[i + 1] = x; f[i + 2] = y; f[i + 3] = w; f[i + 4] = h; f[i + 5] = r; f[i + 6] = width; this.u[i + 7] = pack(c);
        this.n += 8; return this;
    }
    rampRect(x, y, w, h, r, stops, spanX, spanW) {
        if (!(w > 0 && h > 0)) return this;
        this._grow(9); const f = this.f, i = this.n;
        this.u[i] = OP.RAMPRECT; f[i + 1] = x; f[i + 2] = y; f[i + 3] = w; f[i + 4] = h; f[i + 5] = r;
        const rid = rampId(stops); this.ramps.add(rid);
        this.u[i + 6] = rid; f[i + 7] = spanX == null ? x : spanX; f[i + 8] = spanW == null ? w : spanW;
        this.n += 9; return this;
    }
    circle(cx, cy, r, c) { return this.arc(cx, cy, 0, r, 0, 360, c); }
    arc(cx, cy, r0, r1, a0, a1, c, opts) {
        this._grow(12); const f = this.f, i = this.n;
        const ramp = opts && opts.ramp;
        let flags = opts && opts.round ? 1 : 0, rf = 0, rt = 0, rid = 0;
        if (ramp) {
            flags |= 2; rid = rampId(ramp); this.ramps.add(rid);
            rf = opts.rampFrom == null ? Math.min(a0, a1) : opts.rampFrom;
            rt = opts.rampTo == null ? Math.max(a0, a1) : opts.rampTo;
        }
        this.u[i] = OP.ARC; f[i + 1] = cx; f[i + 2] = cy; f[i + 3] = r0; f[i + 4] = r1; f[i + 5] = a0; f[i + 6] = a1;
        this.u[i + 7] = pack(c || [0, 0, 0, 0]); this.u[i + 8] = flags; this.u[i + 9] = rid; f[i + 10] = rf; f[i + 11] = rt;
        this.n += 12; return this;
    }
    line(xa, ya, xb, yb, width, c) {
        this._grow(7); const f = this.f, i = this.n;
        this.u[i] = OP.LINE; f[i + 1] = xa; f[i + 2] = ya; f[i + 3] = xb; f[i + 4] = yb; f[i + 5] = width; this.u[i + 6] = pack(c);
        this.n += 7; return this;
    }
    polyline(pts, width, c) {
        const col = pack(c);
        for (let i = 1; i < pts.length; i++) this.line(pts[i - 1][0], pts[i - 1][1], pts[i][0], pts[i][1], width, col);
        return this;
    }
    /** Filled convex quad (anti-aliased), points in order: [[x,y] x4] */
    quad(pts, c) {
        this._grow(10); const f = this.f; let i = this.n;
        this.u[i++] = OP.QUAD;
        for (let k = 0; k < 4; k++) { f[i++] = pts[k][0]; f[i++] = pts[k][1]; }
        this.u[i++] = pack(c);
        this.n = i; return this;
    }
    /** Area under a trace down to baseY (two triangles per segment). */
    fillUnder(pts, baseY, c) {
        if (pts.length < 2) return this;
        const col = pack(c), k = (pts.length - 1) * 2;
        this._grow(2 + k * 9); const f = this.f, u = this.u; let i = this.n;
        u[i++] = OP.TRIS; u[i++] = k;
        for (let s = 1; s < pts.length; s++) {
            const xa = pts[s - 1][0], ya = pts[s - 1][1], xb = pts[s][0], yb = pts[s][1];
            f[i++] = xa; f[i++] = ya; u[i++] = col; f[i++] = xb; f[i++] = yb; u[i++] = col; f[i++] = xb; f[i++] = baseY; u[i++] = col;
            f[i++] = xa; f[i++] = ya; u[i++] = col; f[i++] = xb; f[i++] = baseY; u[i++] = col; f[i++] = xa; f[i++] = baseY; u[i++] = col;
        }
        this.n = i; return this;
    }
    /** Global opacity (0..1) for what follows; 1 to end. */
    alpha(a) { this._grow(2); this.u[this.n++] = OP.ALPHA; this.f[this.n++] = a; return this; }
    /**
     * Transform for what follows: device px = v * s + (ox, oy); xf() = back to the placement's.
     * Used by the display for the screen chrome (header, menu bar) drawn in screen pixels.
     */
    xf(s, ox, oy) { this._bgOff(); this._grow(4); const f = this.f, i = this.n; this.u[i] = OP.XF; f[i + 1] = s || 0; f[i + 2] = ox || 0; f[i + 3] = oy || 0; this.n += 4; return this; }
    /** Append another recording (its fonts, ramps and layers come along). */
    append(r) {
        this._bgOff();
        const w = r.words();
        this._grow(w.length); this.u.set(w, this.n); this.n += w.length;
        r.atlases.forEach((a) => this.atlases.add(a)); r.ramps.forEach((a) => this.ramps.add(a));
        if (r.images) r.images.forEach((id) => this.images.add(id));
        if (r.layersUsed) r.layersUsed.forEach((id) => (this.layersUsed || (this.layersUsed = new Set())).add(id));
        return this;
    }
    clip(x, y, w, h) { this._bgOff(); this._grow(5); const f = this.f, i = this.n; this.u[i] = OP.CLIP; f[i + 1] = x; f[i + 2] = y; f[i + 3] = w; f[i + 4] = h; this.n += 5; return this; }
    noclip() { this._bgOff(); this._grow(1); this.u[this.n++] = OP.NOCLIP; return this; }

    /** Text; y is the baseline. Returns the width in logical px (as canvas.js). */
    text(str, x, y, size, c, opts) {
        opts = opts || {};
        const s = arabic.visual(opts.literal ? String(str) : t(str)), family = opts.font || 'label';
        const f = font(family, size * this.textScale, s);
        if (!f) return 0;
        const sc = size / f.size, sp = opts.spacing || 0;
        const w = fonts.measure(f, s) * sc + sp * Math.max(0, s.length - 1);
        let pen = opts.align === 'center' ? x - w / 2 : opts.align === 'right' ? x - w : x;
        let cnt = 0;
        const head = this.n;
        this._grow(4 + s.length * 8);
        const fl = this.f, u = this.u;
        let i = head + 4;
        for (const ch of s) {
            const g = f.glyphs[ch.codePointAt(0)] || f.glyphs[63];
            if (!g) continue;
            const gx = g[0], gy = g[1], gw = g[2], gh = g[3];
            if (gw && gh) {
                fl[i++] = pen + g[4] * sc; fl[i++] = y + g[5] * sc; fl[i++] = gw * sc; fl[i++] = gh * sc;
                fl[i++] = gx; fl[i++] = gy; fl[i++] = gx + gw; fl[i++] = gy + gh;
                cnt++;
            }
            pen += g[6] * sc + sp;
        }
        if (cnt) {
            const aid = atlasId(f, f.family || family); this.atlases.add(aid);
            u[head] = OP.GLYPHS; u[head + 1] = aid; u[head + 2] = pack(c); u[head + 3] = cnt;
            this.n = i;
        }
        return w;
    }
    textWidth(str, size, opts) {
        const s = arabic.visual(opts && opts.literal ? String(str) : t(str)), f = font((opts && opts.font) || 'label', size * this.textScale, s);
        return f ? fonts.measure(f, s) * (size / f.size) + ((opts && opts.spacing) || 0) * Math.max(0, s.length - 1) : 0;
    }

    /** Draw a cached layer (see layer()) at x, y. Canvas layers (old code) are not supported. */
    blit(L, x, y) {
        if (!L || L.layerId === undefined) throw new Error('Recorder.blit: not a layer');
        this._grow(4); const i = this.n;
        this.u[i] = OP.LAYER; this.u[i + 1] = L.layerId; this.f[i + 2] = Math.round(x); this.f[i + 3] = Math.round(y);
        this.n += 4;
        (this.layersUsed || (this.layersUsed = new Set())).add(L.layerId);
        return this;
    }
}

/**
 * A cached layer: draw(recorder) once into a w x h recording. Returned object is passed to
 * Recorder.blit(). The transport uploads it to the renderer (drawn into a texture there) or
 * plays it into a Canvas once for the software path.
 */
function makeLayer(w, h, draw, textScale) {
    const r = new Recorder(Math.ceil(w), Math.ceil(h), { textScale });
    draw(r);
    const L = { layerId: ++layerSeq, w: r.w, h: r.h, words: r.words().slice(), soft: null, sublayers: r.layersUsed, atlases: r.atlases, ramps: r.ramps };
    layerById.set(L.layerId, L);
    return L;
}
function dropLayer(L) { layerById.delete(L.layerId); }

/* ---------- software playback (canvas.js) ---------- */
function softLayer(L) {
    if (!L.soft) { L.soft = new Canvas(L.w, L.h); play(L.words, L.soft); }
    return L.soft;
}

const NOP = new Proxy({}, { get: () => () => 0 });

/**
 * Execute recorded words onto a canvas.js Canvas. Parts drawn under an xf() transform (the
 * GPU screen chrome, in screen pixels) are skipped: they don't belong on the app's image.
 * sc (default 1): canvas pixels per recorded unit (a picture drawn at the size it is shown, e.g.
 * a recording at the page's scale; record its text with the same textScale so it stays sharp).
 */
function play(words, real, sc) {
    let cv = real;
    const k1 = sc > 0 ? sc : 1, S = (v) => v * k1;
    const u = words instanceof Uint32Array ? words : new Uint32Array(words);
    const f = new Float32Array(u.buffer, u.byteOffset, u.length);
    let alpha = 1;
    const col = (v) => { const a = unpack(v); if (alpha < 1) a[3] = Math.round(a[3] * alpha); return a; };
    let clip = null;
    let i = 0;
    const n = u.length;
    while (i < n) {
        const op = u[i++];
        switch (op) {
        case OP.CLEAR: cv.clear(unpack(u[i])); i += 1; break;
        case OP.RECT: cv.fillRect(S(f[i]), S(f[i + 1]), S(f[i + 2]), S(f[i + 3]), col(u[i + 4])); i += 5; break;
        case OP.GRAD: case OP.CARD: {
            const card = op === OP.CARD, x = S(f[i]), y = S(f[i + 1]), w = S(f[i + 2]), h = S(f[i + 3]), r = card ? S(f[i + 4]) : 0;
            const k = u[i + (card ? 5 : 4)]; i += card ? 6 : 5;
            const st = [];
            for (let s = 0; s < k; s++) st.push([f[i + s * 2], col(u[i + s * 2 + 1])]);
            i += k * 2;
            if (card) cv.card(x, y, w, h, r, st); else cv.gradientRect(x, y, w, h, st);
            break;
        }
        case OP.RRECT: cv.roundRect(S(f[i]), S(f[i + 1]), S(f[i + 2]), S(f[i + 3]), S(f[i + 4]), col(u[i + 5])); i += 6; break;
        case OP.RSTROKE: cv.strokeRoundRect(S(f[i]), S(f[i + 1]), S(f[i + 2]), S(f[i + 3]), S(f[i + 4]), S(f[i + 5]), col(u[i + 6])); i += 7; break;
        case OP.RAMPRECT: cv.rampRect(S(f[i]), S(f[i + 1]), S(f[i + 2]), S(f[i + 3]), S(f[i + 4]), rampList[u[i + 5]] || ['#fff'], S(f[i + 6]), S(f[i + 7])); i += 8; break;
        case OP.ARC: {
            const flags = u[i + 7];
            const opts = { round: !!(flags & 1) };
            if (flags & 2) { opts.ramp = rampList[u[i + 8]]; opts.rampFrom = f[i + 9]; opts.rampTo = f[i + 10]; }
            cv.arc(S(f[i]), S(f[i + 1]), S(f[i + 2]), S(f[i + 3]), f[i + 4], f[i + 5], col(u[i + 6]), opts);
            i += 11; break;
        }
        case OP.LINE: cv.line(S(f[i]), S(f[i + 1]), S(f[i + 2]), S(f[i + 3]), S(f[i + 4]), col(u[i + 5])); i += 6; break;
        case OP.QUAD: cv.quad([[S(f[i]), S(f[i + 1])], [S(f[i + 2]), S(f[i + 3])], [S(f[i + 4]), S(f[i + 5])], [S(f[i + 6]), S(f[i + 7])]], col(u[i + 8])); i += 9; break;
        case OP.TRIS: {
            const k = u[i++];
            for (let t = 0; t < k; t++) {
                const b = i + t * 9;
                cv.triangle([[S(f[b]), S(f[b + 1])], [S(f[b + 3]), S(f[b + 4])], [S(f[b + 6]), S(f[b + 7])]], col(u[b + 2]));
            }
            i += k * 9; break;
        }
        case OP.GLYPHS: {
            const fo = atlasById(u[i]), c = col(u[i + 1]), k = u[i + 2]; i += 3;
            if (fo) for (let g = 0; g < k; g++) {
                const b = i + g * 8, gw = f[b + 6] - f[b + 4], gh = f[b + 7] - f[b + 5];
                cv._blit(fo, f[b + 4], f[b + 5], gw, gh, S(f[b]), S(f[b + 1]), S(f[b + 2]) / gw, c);
            }
            i += k * 8; break;
        }
        case OP.LAYER: { const L = layerById.get(u[i]); if (L) cv.blit(softLayer(L), S(f[i + 1]), S(f[i + 2])); i += 3; break; }
        case OP.IMAGE: { const im = imageById.get(u[i]); if (im && cv.drawImage) cv.drawImage(im.data, im.w, im.h, S(f[i + 2]), S(f[i + 3]), S(f[i + 4]), S(f[i + 5])); i += 6; break; }
        case OP.VIDEO: i += 6; break;              // (software path: no video frames; nothing drawn)
        case OP.CLIP: clip = [f[i], f[i + 1], f[i + 2], f[i + 3]]; i += 4; break;     // (software path: ignored)
        case OP.NOCLIP: clip = null; break;
        case OP.ALPHA: alpha = f[i]; i += 1; break;
        case OP.XF: cv = f[i] > 0 ? NOP : real; i += 3; break;
        default: return real;
        }
    }
    void clip;
    return real;
}

module.exports = { Recorder, OP, pack, unpack, rampId, rampList, atlasId, atlasList, atlasById, markBadAtlas, badAtlas, makeLayer, dropLayer, layerById, play, softLayer, setImage, dropImage, imageById };
